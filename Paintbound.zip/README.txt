CONTROLS
- A = LEFT
- D = RIGHT
- SPACE = JUMP
- SHIFT = DASH
- Q = CHANGE PAINT COLOUR
- E = SHOOT PAINT SHOT
- ALT = SLOW WALK
- HOLD INTO WALL IN AIR + SPACE = WALL JUMP (CAN BE REPEATED)
- R = RESTART
- ESC = QUIT

COLOURS AND THEIR EFFECTS

Yellow - Speed boost! Gives you a flat 1.5x move speed and gives ground acceleration that builds for every second you move on yellow tiles.         decreases gradually when running on non-yellow tiles. Doesn't decrease in the air. TIP : it takes more than one yellow tile in a row to reach max speed!

Red - Allows you to double jump! Just press space in the air after jumping and you'll jump again. TIP : you can double jump after wall jumping, and if you touch a red block from the side that will also give you a double jump (you'll need that for level 13!)

Blue - Bounces you! If you land on a blue block while falling you will bounce up in the air. TIP : the speed you bounce up with depends on the speed you fall down with, so the higher you jump from before hitting a blue block the better (don't forget about red blocks!)

Black - Sticks to your head! Just jump up into a black block from below and you'll stick to it. To fall off, simply move off the black blocks so your head is no longer touching one. TIP : if you run along yellow blocks and get speed, then stick to a black block, your speed won't be decreased (keep that in mind for level 13!)



A Note - Blocks do not reset when you fall off. They only reset when you press R. Use this to your advantage!